package dev.vclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Отрисовка красивого HUD. */
public final class Hud {
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final int LABEL_COLOR = 0xFFA8A8B8;
    private static final int VALUE_COLOR = 0xFFFFFFFF;
    private static final String TITLE = "VCLIENT";

    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (!Config.hud || player == null || mc.options.hudHidden) return;

        float s = Config.scale();
        ctx.getMatrices().push();
        ctx.getMatrices().scale(s, s, 1.0f);

        TextRenderer tr = mc.textRenderer;
        int accent = Config.color();

        List<String[]> rows = new ArrayList<>();
        if (Config.fps) {
            rows.add(new String[]{"FPS", String.valueOf(mc.getCurrentFps())});
        }
        if (Config.coords) {
            rows.add(new String[]{"XYZ", String.format(Locale.ROOT, "%d  %d  %d",
                    MathHelper.floor(player.getX()), MathHelper.floor(player.getY()), MathHelper.floor(player.getZ()))});
        }
        if (Config.direction) {
            String f = player.getHorizontalFacing().asString();
            rows.add(new String[]{"DIR", Character.toUpperCase(f.charAt(0)) + f.substring(1)});
        }
        if (Config.ping) {
            ClientPlayNetworkHandler handler = mc.getNetworkHandler();
            PlayerListEntry entry = handler == null ? null : handler.getPlayerListEntry(player.getUuid());
            if (entry != null) {
                rows.add(new String[]{"PING", entry.getLatency() + " ms"});
            }
        }

        if (!rows.isEmpty()) {
            drawInfoPanel(ctx, tr, rows, accent);
        }
        if (Config.armor) {
            drawArmor(ctx, mc, tr, player, s, accent);
        }

        ctx.getMatrices().pop();
    }

    private static void drawInfoPanel(DrawContext ctx, TextRenderer tr, List<String[]> rows, int accent) {
        int pad = 7;
        int x = 8;
        int y = 8;
        int w = tr.getWidth(TITLE) + 40;
        for (String[] row : rows) {
            w = Math.max(w, tr.getWidth(row[0]) + 16 + tr.getWidth(row[1]));
        }
        w += pad * 2;
        int h = pad + 14 + rows.size() * 11 + pad - 1;

        RenderUtil.glassPanel(ctx, x, y, w, h, 6, accent);

        ctx.drawTextWithShadow(tr, Text.literal(TITLE).formatted(Formatting.BOLD), x + pad, y + pad, accent);
        ctx.fill(x + pad, y + pad + 10, x + w - pad, y + pad + 11, RenderUtil.argb(0x40, 0xFFFFFF));

        int ty = y + pad + 14;
        for (String[] row : rows) {
            ctx.drawTextWithShadow(tr, row[0], x + pad, ty, LABEL_COLOR);
            ctx.drawTextWithShadow(tr, row[1], x + w - pad - tr.getWidth(row[1]), ty, VALUE_COLOR);
            ty += 11;
        }
    }

    private static void drawArmor(DrawContext ctx, MinecraftClient mc, TextRenderer tr,
                                  ClientPlayerEntity player, float scale, int accent) {
        List<ItemStack> stacks = new ArrayList<>();
        for (EquipmentSlot slot : ARMOR) {
            ItemStack stack = player.getEquippedStack(slot);
            if (!stack.isEmpty()) stacks.add(stack);
        }
        if (stacks.isEmpty()) return;

        int w = 26;
        int h = stacks.size() * 18 + 8;
        int x = (int) (ctx.getScaledWindowWidth() / scale) - w - 8;
        int y = 8;

        RenderUtil.glassPanel(ctx, x, y, w, h, 6, accent);
        int iy = y + 4;
        for (ItemStack stack : stacks) {
            ctx.drawItem(stack, x + 6, iy);
            ctx.drawStackOverlay(tr, stack, x + 6, iy);
            iy += 18;
        }
    }
}
