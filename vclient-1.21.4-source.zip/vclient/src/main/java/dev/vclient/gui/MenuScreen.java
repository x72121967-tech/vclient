package dev.vclient.gui;

import dev.vclient.Config;
import dev.vclient.RenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Меню настроек: крупные кнопки в две колонки, удобно для сенсорного экрана. */
public class MenuScreen extends Screen {
    private static final int BUTTON_HEIGHT = 24;
    private static final int GAP = 4;

    private final Screen parent;
    private final List<ButtonWidget> items = new ArrayList<>();
    private int panelX, panelY, panelW, panelH;
    private int titleY;

    public MenuScreen(Screen parent) {
        super(Text.literal("VClient"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        items.clear();
        int colWidth = Math.min(150, (width - 40) / 2);
        int totalWidth = colWidth * 2 + GAP;
        int left = (width - totalWidth) / 2;

        String[] toggleNames = {"HUD", "FPS", "Coords", "Direction", "Ping", "Armor", "Fullbright", "Glow"};
        BooleanSupplier[] getters = {
                () -> Config.hud, () -> Config.fps, () -> Config.coords, () -> Config.direction,
                () -> Config.ping, () -> Config.armor, () -> Config.fullbright, () -> Config.glow};
        List<Consumer<Boolean>> setters = List.of(
                v -> Config.hud = v, v -> Config.fps = v, v -> Config.coords = v, v -> Config.direction = v,
                v -> Config.ping = v, v -> Config.armor = v, v -> Config.fullbright = v, v -> Config.glow = v);

        int total = toggleNames.length + 3; // + Color, Scale, Opacity
        int rows = (total + 1) / 2;
        int contentH = rows * (BUTTON_HEIGHT + GAP) + BUTTON_HEIGHT + 22;
        int top = Math.max(26, (height - contentH) / 2 + 14);
        titleY = top - 16;

        int index = 0;
        for (int i = 0; i < toggleNames.length; i++) {
            final String name = toggleNames[i];
            final BooleanSupplier get = getters[i];
            final Consumer<Boolean> set = setters.get(i);
            int[] p = pos(left, top, colWidth, index++);
            ButtonWidget b = ButtonWidget.builder(toggleLabel(name, get.getAsBoolean()), button -> {
                set.accept(!get.getAsBoolean());
                button.setMessage(toggleLabel(name, get.getAsBoolean()));
            }).dimensions(p[0], p[1], colWidth, BUTTON_HEIGHT).build();
            addDrawableChild(b);
        }

        int[] p = pos(left, top, colWidth, index++);
        addDrawableChild(ButtonWidget.builder(colorLabel(), button -> {
            Config.colorIndex = (Config.colorIndex + 1) % Config.COLORS.length;
            button.setMessage(colorLabel());
        }).dimensions(p[0], p[1], colWidth, BUTTON_HEIGHT).build());

        p = pos(left, top, colWidth, index++);
        addDrawableChild(ButtonWidget.builder(scaleLabel(), button -> {
            Config.scaleIndex = (Config.scaleIndex + 1) % Config.SCALES.length;
            button.setMessage(scaleLabel());
        }).dimensions(p[0], p[1], colWidth, BUTTON_HEIGHT).build());

        p = pos(left, top, colWidth, index++);
        addDrawableChild(ButtonWidget.builder(opacityLabel(), button -> {
            Config.opacityIndex = (Config.opacityIndex + 1) % Config.OPACITIES.length;
            button.setMessage(opacityLabel());
        }).dimensions(p[0], p[1], colWidth, BUTTON_HEIGHT).build());

        int doneY = top + rows * (BUTTON_HEIGHT + GAP);
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(left, doneY, totalWidth, BUTTON_HEIGHT).build());

        panelX = left - 8;
        panelY = titleY - 8;
        panelW = totalWidth + 16;
        panelH = doneY + BUTTON_HEIGHT + 8 - panelY;
    }

    private int[] pos(int left, int top, int colWidth, int index) {
        int col = index % 2;
        int row = index / 2;
        return new int[]{left + col * (colWidth + GAP), top + row * (BUTTON_HEIGHT + GAP)};
    }

    private static Text toggleLabel(String label, boolean on) {
        return Text.literal(label + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    private static Text colorLabel() {
        return Text.literal("Color: " + Config.COLOR_NAMES[Config.colorIndex]);
    }

    private static Text scaleLabel() {
        return Text.literal("Scale: " + Config.scale() + "x");
    }

    private static Text opacityLabel() {
        return Text.literal("Glass: " + Config.OPACITY_NAMES[Config.opacityIndex]);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0x70000000);
        RenderUtil.glassPanel(context, panelX, panelY, panelW, panelH, 8, Config.color());
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, titleY, Config.color());
    }

    @Override
    public void close() {
        Config.save();
        if (client != null) {
            client.setScreen(parent);
        }
    }
}
