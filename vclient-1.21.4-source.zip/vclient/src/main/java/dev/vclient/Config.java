package dev.vclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Настройки клиента. Хранятся в config/vclient.properties. */
public final class Config {
    public static boolean hud = true;
    public static boolean fps = true;
    public static boolean coords = true;
    public static boolean direction = true;
    public static boolean ping = true;
    public static boolean armor = true;
    public static boolean fullbright = false;
    public static boolean glow = true;
    public static int opacityIndex = 1;
    public static int colorIndex = 1;
    public static int scaleIndex = 1;

    public static final int[] COLORS = {0xFFFFFFFF, 0xFF55FFFF, 0xFF55FF55, 0xFFFFAA00, 0xFFFF5555, 0xFFFF55FF};
    public static final String[] COLOR_NAMES = {"White", "Aqua", "Green", "Orange", "Red", "Pink"};
    public static final int[] OPACITIES = {0x55, 0x80, 0xB0};
    public static final String[] OPACITY_NAMES = {"Low", "Medium", "High"};
    public static final float[] SCALES = {0.75f, 1.0f, 1.25f, 1.5f, 2.0f};

    private Config() {}

    public static int color() {
        return COLORS[colorIndex];
    }

    public static int opacity() {
        return OPACITIES[opacityIndex];
    }

    public static float scale() {
        return SCALES[scaleIndex];
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("vclient.properties");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(path)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        hud = bool(p, "hud", hud);
        fps = bool(p, "fps", fps);
        coords = bool(p, "coords", coords);
        direction = bool(p, "direction", direction);
        ping = bool(p, "ping", ping);
        armor = bool(p, "armor", armor);
        fullbright = bool(p, "fullbright", fullbright);
        glow = bool(p, "glow", glow);
        opacityIndex = idx(p, "opacity", opacityIndex, OPACITIES.length);
        colorIndex = idx(p, "color", colorIndex, COLORS.length);
        scaleIndex = idx(p, "scale", scaleIndex, SCALES.length);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hud", String.valueOf(hud));
        p.setProperty("fps", String.valueOf(fps));
        p.setProperty("coords", String.valueOf(coords));
        p.setProperty("direction", String.valueOf(direction));
        p.setProperty("ping", String.valueOf(ping));
        p.setProperty("armor", String.valueOf(armor));
        p.setProperty("fullbright", String.valueOf(fullbright));
        p.setProperty("glow", String.valueOf(glow));
        p.setProperty("opacity", String.valueOf(opacityIndex));
        p.setProperty("color", String.valueOf(colorIndex));
        p.setProperty("scale", String.valueOf(scaleIndex));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "VClient");
        } catch (IOException ignored) {
        }
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static int idx(Properties p, String key, int def, int size) {
        try {
            int v = Integer.parseInt(p.getProperty(key, String.valueOf(def)));
            return v >= 0 && v < size ? v : def;
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
