package dev.vclient;

import net.minecraft.client.gui.DrawContext;

/** Рисование скруглённых «стеклянных» панелей без шейдеров (работает и на телефоне). */
public final class RenderUtil {
    private RenderUtil() {}

    public static int argb(int alpha, int rgb) {
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        int a = (int) (((c1 >>> 24) & 0xFF) * (1 - t) + ((c2 >>> 24) & 0xFF) * t);
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Скруглённый прямоугольник с вертикальным градиентом. */
    public static void roundedGradient(DrawContext ctx, int x1, int y1, int x2, int y2, int radius, int top, int bottom) {
        int h = y2 - y1;
        int w = x2 - x1;
        if (h <= 0 || w <= 0) return;
        int r = Math.max(0, Math.min(radius, Math.min(w / 2, h / 2)));
        for (int row = 0; row < h; row++) {
            int k = row < r ? row : (row >= h - r ? h - 1 - row : -1);
            int inset = 0;
            if (k >= 0) {
                double dy = r - (k + 0.5);
                inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            }
            float t = h <= 1 ? 0f : (float) row / (h - 1);
            ctx.fill(x1 + inset, y1 + row, x2 - inset, y1 + row + 1, lerp(top, bottom, t));
        }
    }

    /**
     * «Матовое стекло»: мягкое свечение, светлая кромка, полупрозрачная тёмная основа
     * с градиентом и акцентная полоска слева. Размытие имитируется слоями прозрачности.
     */
    public static void glassPanel(DrawContext ctx, int x, int y, int w, int h, int radius, int accent) {
        int a = Config.opacity();
        if (Config.glow) {
            for (int i = 4; i >= 1; i--) {
                int alpha = 6 + (5 - i) * 3;
                roundedGradient(ctx, x - i, y - i, x + w + i, y + h + i, radius + i,
                        argb(alpha, accent), argb(alpha, accent));
            }
        }
        // светлая кромка (на неё сверху ложится тёмная основа, получается «стекло»)
        roundedGradient(ctx, x, y, x + w, y + h, radius, 0x38FFFFFF, 0x14FFFFFF);
        // основа
        roundedGradient(ctx, x + 1, y + 1, x + w - 1, y + h - 1, radius - 1,
                argb(a, 0x24243A), argb(a, 0x0A0A12));
        // блик сверху
        roundedGradient(ctx, x + 2, y + 1, x + w - 2, y + 1 + Math.max(2, h / 3), radius - 1,
                0x1CFFFFFF, 0x00FFFFFF);
        // акцентная полоска
        ctx.fill(x, y + radius, x + 2, y + h - radius, accent);
    }
}
