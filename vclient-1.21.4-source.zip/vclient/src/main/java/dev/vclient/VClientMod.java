package dev.vclient;

import dev.vclient.gui.MenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class VClientMod implements ClientModInitializer {
    private static KeyBinding menuKey;
    private boolean fullbrightApplied;

    @Override
    public void onInitializeClient() {
        Config.load();

        // Клавиша меню (на телефоне её можно повесить на экранную кнопку в MojoLauncher).
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.vclient"));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(Hud::render);

        // Команда /vc открывает меню прямо из чата.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("vc").executes(context -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new MenuScreen(null)));
                    return 1;
                })));

        // Кнопка VClient в меню паузы: удобно нажимать пальцем.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("VClient"),
                                button -> client.setScreen(new MenuScreen(screen)))
                        .dimensions(6, 6, 80, 24)
                        .build());
            }
        });
    }

    private void onTick(MinecraftClient client) {
        while (menuKey.wasPressed()) {
            client.setScreen(new MenuScreen(null));
        }

        ClientPlayerEntity player = client.player;
        if (player == null) {
            fullbrightApplied = false;
            return;
        }

        if (Config.fullbright) {
            StatusEffectInstance current = player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (current == null || (fullbrightApplied && current.getDuration() < 300)) {
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, 600, 0, true, false, false));
                fullbrightApplied = true;
            }
        } else if (fullbrightApplied) {
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fullbrightApplied = false;
        }
    }
}
